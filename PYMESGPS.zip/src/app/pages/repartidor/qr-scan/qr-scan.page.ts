import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qr-scan',
  templateUrl: './qr-scan.page.html',
  styleUrls: ['./qr-scan.page.scss'],
})
export class QrScanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
