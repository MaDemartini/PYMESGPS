import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController } from '@ionic/angular';
import { NotificacionesService } from 'src/app/services/notificaciones/notificaciones.service';
import { AuthServiceService } from 'src/app/services/autentificacion/autentificacion.service';
import { ClienteService } from 'src/app/services/Usuarios/cliente/cliente.service';
import { Notificacion } from 'src/app/models/notificacion';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-home-cliente',
  templateUrl: './home-cliente.page.html',
  styleUrls: ['./home-cliente.page.scss'],
})
export class HomeClientePage implements OnInit {
  cliente: boolean = false;
  clienteData: any;
  codigoSeguimiento: string = '';
  notificaciones: Notificacion[] = []; // Notificaciones del cliente
  mostrarNotificacionesLista: boolean = false; // Control de visibilidad para la lista de notificaciones

  constructor(
    private menuCtrl: MenuController,
    private clienteService: ClienteService,
    private authService: AuthServiceService,
    private notificacionesService: NotificacionesService,
    private router: Router
  ) {}

  ngOnInit() {
    this.cargarCliente();
    this.cargarNotificaciones();
    this.menuCtrl.enable(true);
  }

  openMenu() {
    this.menuCtrl.open();
  }

  closeMenu() {
    this.menuCtrl.close();
  }

  async cargarCliente() {
    const usuario = await this.authService.getDecryptedUserData();
    if (usuario && usuario.id_cliente) {
      this.cliente = true;
      const clienteInfo = await lastValueFrom(this.clienteService.obtenerClientePorId(usuario.id_cliente));
      this.clienteData = Array.isArray(clienteInfo) ? clienteInfo[0] : clienteInfo;
    } else {
      this.cliente = false;
      this.clienteData = null;
    }
  }

  async cargarNotificaciones() {
    try {
      const usuario = await this.authService.getDecryptedUserData();
      if (usuario && usuario.id_cliente) {
        this.notificaciones = await lastValueFrom(
          this.notificacionesService.obtenerNotificaciones(usuario.id_cliente, 3) 
        );
      }
    } catch (error) {
      console.error('Error al cargar las notificaciones:', error);
    }
  }

  async marcarNotificacionComoLeida(idNotificacion: number) {
    try {
      await lastValueFrom(this.notificacionesService.marcarComoLeida(idNotificacion));
      // Actualizar la lista de notificaciones al eliminar la marcada como leída
      this.notificaciones = this.notificaciones.filter(n => n.id_notificacion !== idNotificacion);
    } catch (error) {
      console.error('Error al marcar la notificación como leída:', error);
    }
  }

  mostrarNotificaciones() {
    this.mostrarNotificacionesLista = !this.mostrarNotificacionesLista;
  }

  rastrearPedido() {
    if (this.codigoSeguimiento) {
        this.router.navigate(['/seguimiento'], { state: { codigo: this.codigoSeguimiento } });
    } else {
        console.error('Por favor ingresa un código de seguimiento');
    }
  }

  
  // Métodos para navegar
  goToProfile() {
    this.router.navigate(['/perfil']);
  }

  logout() {
    this.router.navigate(['/login']);
  }

  goToConfig() {
    this.router.navigate(['/configuracion']);
  }

  goToSupport() {
    this.router.navigate(['/soporte']);
  }
}
