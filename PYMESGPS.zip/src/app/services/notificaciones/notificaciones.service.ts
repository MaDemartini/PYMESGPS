import { Injectable } from '@angular/core';
import { ApiConfigService } from '../apiconfig/apiconfig.service';
import { Observable } from 'rxjs';
import { Notificacion } from 'src/app/models/notificacion';
import { HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NotificacionesService {
  private path = 'notificaciones';

  constructor(private apiService: ApiConfigService) {}

  // Método para obtener notificaciones por id_usuario y id_rol
  obtenerNotificaciones(id_usuario: number, id_rol: number): Observable<Notificacion[]> {
    const params = new HttpParams()
      .set('id_usuario', id_usuario.toString())
      .set('id_rol', id_rol.toString());
    return this.apiService.get<Notificacion[]>(this.path, { params });
  }

  // Crear una nueva notificación
  crearNotificacion(notificacion: Notificacion): Observable<Notificacion> {
    return this.apiService.post<Notificacion>(this.path, notificacion);
  }

  // Marcar notificación como leída
  marcarComoLeida(id_notificacion: number): Observable<void> {
    return this.apiService.patch<void>(`${this.path}?id_notificacion=eq.${id_notificacion}`, { leido: true });
  }

  // Eliminar una notificación
  eliminarNotificacion(id_notificacion: number): Observable<void> {
    return this.apiService.delete<void>(`${this.path}?id_notificacion=eq.${id_notificacion}`);
  }
}
