import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ApiConfigService } from '../apiconfig/apiconfig.service';
import { Producto } from 'src/app/models/producto';
import { firstValueFrom, Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { CrearProducto } from 'src/app/models/Crear/crearProducto';

@Injectable({
  providedIn: 'root',
})
export class ProductoService {
  private path = 'producto';  // Nombre de la tabla en Supabase

  constructor(private apiService: ApiConfigService, private http: HttpClient) {}

  // Obtener productos por emprendedor en sesión
  obtenerProductosPorEmprendedor(id_emprendedor: number): Observable<Producto[]> {
    const params = new HttpParams().set('select', '*, inventario(*)').set('id_emprendedor', `eq.${id_emprendedor}`);
    return this.apiService.get<Producto[]>(this.path, { params });
  }

  // Obtener todos los productos
  obtenerTodosLosProductos(): Observable<Producto[]> {
    const params = new HttpParams().set('select', '*, inventario(*)'); // Aseguramos que el inventario se traiga
    return this.apiService.get<Producto[]>(this.path, { params }).pipe(
      map((productos) => {
        productos.forEach(producto => {
          if (!producto.inventario) {
            // Asignar valores por defecto para evitar errores
            producto.inventario = {
              id_inventario: 0,  // Valor por defecto para id_inventario
              cantidad_disponible: 0,
              umbral_reabastecimiento: 0,  // Opcional
              fecha_actualizacion: new Date()  // Opcional
            };
          }
        });
        return productos;
      }),
      catchError((error) => {
        console.error('Error al obtener productos:', error);
        throw error;
      })
    );
  }

  // Obtener un producto por ID con inventario
  obtenerProductoPorId(id: number): Observable<Producto> {
    const params = new HttpParams().set('select', '*, inventario(*)');
    return this.apiService.get<Producto>(`${this.path}?id_producto=eq.${id}`, { params });
  }

  // Agregar un nuevo producto
  agregarProducto(nuevoProducto: CrearProducto): Observable<CrearProducto> {
    return this.apiService.post<CrearProducto>(this.path, nuevoProducto).pipe(
      map((response: CrearProducto) => {
        if (response && response.id_producto) {
          return response;
        } else {
          throw new Error('No se generó id_producto en la respuesta.');
        }
      })
    );
  }

  // Actualizar el producto con id_inventario
  actualizarProducto(id: number, producto: Partial<Producto>): Observable<Producto> {
    return this.apiService.patch<Producto>(`${this.path}?id_producto=eq.${id}`, producto);
  }

  // Método para actualizar el inventario de un producto
  actualizarInventario(id_producto: number, data: Partial<{ cantidad_disponible: number }>): Observable<any> {
    return this.apiService.patch(`inventario?id_producto=eq.${id_producto}`, data);
  }
  
  // Eliminar un producto (soft delete)
  eliminarProducto(id: number): Observable<void> {
    const data = { estado_prod: 'inactivo' };
    return this.apiService.patch<void>(`${this.path}?id_producto=eq.${id}`, data);
  }
}
