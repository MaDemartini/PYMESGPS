export interface LoteProductoSimplificado {
  id_lote_producto: number;
  id_lote: number;
  id_producto: number;
  cantidad: number;
}
