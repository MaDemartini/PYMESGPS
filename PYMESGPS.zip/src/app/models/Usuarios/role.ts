export interface Role {
    id_role: number;
    nombre_role: string;
  }
  