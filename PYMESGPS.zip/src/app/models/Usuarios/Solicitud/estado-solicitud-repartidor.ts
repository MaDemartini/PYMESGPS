export interface EstadoSolicitudRepartidor {
    id_estado: number;
    nombre_estado: string; 
  }
  