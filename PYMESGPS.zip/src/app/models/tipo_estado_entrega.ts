export interface TipoEstadoEntrega {
    id_tipo_estado: number;
    nombre_estado: string;
    descripcion_estado?: string;
  }
  