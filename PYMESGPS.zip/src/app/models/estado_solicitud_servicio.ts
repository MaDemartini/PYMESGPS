export interface EstadoSolicitudServicio {
    id_estado_solicitud: number;
    nombre_estado: string;
    descripcion_estado?: string;
  }
  