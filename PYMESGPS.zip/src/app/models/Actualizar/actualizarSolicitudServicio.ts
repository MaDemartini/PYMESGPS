export interface ActualizarSolicitudServicio {
  estado_solicitud?: string;
  observacion?: string;
}
