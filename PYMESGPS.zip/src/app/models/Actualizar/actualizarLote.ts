export interface ActualizarLote {
  nombre_lote?: string;
  precio_lote?: number;
  codigo_seguimiento?: string;
}
