export interface ActualizarInventario {
  cantidad_disponible: number;
  umbral_reabastecimiento: number;
  fecha_actualizacion: Date;
}
