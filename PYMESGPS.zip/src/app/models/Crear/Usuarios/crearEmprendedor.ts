export interface CrearEmprendedor {
  nombre_completo: string;
  correo: string;
  username: string;
  contrasena: string;
  id_role: number; 
}
